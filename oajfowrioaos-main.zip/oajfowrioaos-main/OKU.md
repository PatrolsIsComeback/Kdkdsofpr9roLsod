# v14 Erasty Uptime



--------------------------------------


Bu Bot Altyapısı YouTube Erasty'e aittir Düzenlenerek Sizlere Sunulmuștur.


## Kurulumlar

[Discord Developer Portal](https://discord.com/developers/applications/) adresine girerek app'inizi oluşturun ve "Bot" sekmesinden Add Bot ardindan Yes Do It! diyerek botunuzu oluşturun. Aynı sekmeden tokeninizi kopyalayıp .env adlı dosyadaki 'token' kısmına yapıştırın.

---
Botununuzun sorunsuz olarak çalışması için [Discord Developer Portal](https://discord.com/developers/applications/) adresinden yine bot sekmesine girip Priviliged Gateway Intents başlığı altındaki butun intentleri açmayı unutmayın.

---
YouTube [Erasty](https://www.youtube.com/channel/UC-nU4WHUTfr3KJJmxD_2Twg/?sub_confirmation=1)

Discord Sunucumuz [Erasty Development](https://discord.gg/PqDVN6D47c)

--------------------------------------


      
     Bizler için 💎 Değerlisiniz...
